import UIKit

final class GigachatMessageBubbleView: UIView {
    private let bubbleContainer = UIView()
    private let messageLabel = UILabel()

    init(text: String) {
        super.init(frame: .zero)
        setup(text: text)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setup(text: String) {
        translatesAutoresizingMaskIntoConstraints = false

        bubbleContainer.translatesAutoresizingMaskIntoConstraints = false
        bubbleContainer.backgroundColor = UIColor(red: 0.92, green: 0.93, blue: 0.98, alpha: 1.0)
        bubbleContainer.layer.cornerRadius = 18
        bubbleContainer.layer.masksToBounds = true

        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.numberOfLines = 0
        messageLabel.text = text
        messageLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        messageLabel.textColor = UIColor(red: 0.08, green: 0.08, blue: 0.10, alpha: 1.0)
        messageLabel.lineBreakMode = .byWordWrapping

        bubbleContainer.addSubview(messageLabel)
        addSubview(bubbleContainer)

        NSLayoutConstraint.activate([
            messageLabel.topAnchor.constraint(equalTo: bubbleContainer.topAnchor, constant: 12),
            messageLabel.leadingAnchor.constraint(equalTo: bubbleContainer.leadingAnchor, constant: 18),
            messageLabel.trailingAnchor.constraint(equalTo: bubbleContainer.trailingAnchor, constant: -18),
            messageLabel.bottomAnchor.constraint(equalTo: bubbleContainer.bottomAnchor, constant: -12),

            bubbleContainer.topAnchor.constraint(equalTo: topAnchor),
            bubbleContainer.trailingAnchor.constraint(equalTo: trailingAnchor),
            bubbleContainer.bottomAnchor.constraint(equalTo: bottomAnchor),
            bubbleContainer.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 56),
            bubbleContainer.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 0.78)
        ])
    }
}
