import SwiftUI

struct EditableNameRow: View {
    @Binding var name: String

    @State private var isEditing = false
    @FocusState private var isFocused: Bool

    var body: some View {
        HStack {
            if isEditing {
                TextField("Имя", text: $name)
                    .focused($isFocused)
                    .textFieldStyle(.plain)
                    .onSubmit {
                        stopEditing()
                    }
            } else {
                Text(name)
                    .foregroundStyle(Color(red: 0.69, green: 0.74, blue: 0.80))
                    .font(.system(size: 15, weight: .regular))
                    .onTapGesture {
                        startEditing()
                    }
            }

            Spacer()

            Button {
                if isEditing {
                    stopEditing()
                } else {
                    startEditing()
                }
            } label: {
                Image(systemName: isEditing ? "checkmark" : "pencil")
                    .foregroundStyle(Color(red: 0.70, green: 0.88, blue: 0.97))
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
    }

    private func startEditing() {
        isEditing = true
        isFocused = true
    }

    private func stopEditing() {
        isEditing = false
        isFocused = false
    }
}
