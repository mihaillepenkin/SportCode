import SwiftUI

struct BottomTabBar: View {
    @Binding var selectedTab: AppTab
    var onPrimaryTabTap: (() -> Void)?

    var body: some View {
        HStack(alignment: .center, spacing: 0) {
            ForEach(AppTab.allCases) { tab in
                Button {
                    select(tab)
                } label: {
                    TabBarItem(tab: tab, isSelected: selectedTab == tab)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(tab.title)
            }
        }
        .frame(height: 78)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .shadow(color: Color.black.opacity(0.06), radius: 20, y: 8)
    }

    private func select(_ tab: AppTab) {
        if tab.isPrimary, let onPrimaryTabTap {
            onPrimaryTabTap()
            return
        }

        selectedTab = tab
    }
}

#Preview {
    BottomTabBar(selectedTab: .constant(.bank))
        .padding()
        .background(Color(red: 0.97, green: 0.98, blue: 1.0))
}
