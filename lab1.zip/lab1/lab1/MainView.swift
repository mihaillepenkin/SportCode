import SwiftUI

struct MainView: View {
    @State private var selectedTab: AppTab = .bank
    @State private var isGigachatPresented = false

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.97, green: 0.98, blue: 1.0)
                    .ignoresSafeArea()

                VStack {
                    HStack {
                        NavigationLink(value: MainRoute.profile) {
                            AvatarView(size: 42)
                                .shadow(color: Color.black.opacity(0.08), radius: 10, y: 4)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Открыть профиль")

                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)

                    Spacer()
                }
            }
            .safeAreaInset(edge: .bottom) {
                BottomTabBar(selectedTab: $selectedTab) {
                    isGigachatPresented = true
                }
                    .padding(.horizontal, 10)
                    .padding(.bottom, 8)
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: MainRoute.self) { route in
                switch route {
                case .profile:
                    ProfileView()
                }
            }
        }
        .fullScreenCover(isPresented: $isGigachatPresented) {
            GigachatView {
                isGigachatPresented = false
            }
            .ignoresSafeArea()
        }
    }
}

private enum MainRoute: Hashable {
    case profile
}

#Preview {
    MainView()
}
