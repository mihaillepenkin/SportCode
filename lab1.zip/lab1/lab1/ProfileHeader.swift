import SwiftUI

struct ProfileHeader: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            Text("Профиль")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(Color(red: 0.06, green: 0.07, blue: 0.10))

            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(Color(red: 0.68, green: 0.83, blue: 0.91))
                        .frame(width: 40, height: 40)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }

                Spacer()
            }
        }
        .padding(.top, 8)
    }
}
