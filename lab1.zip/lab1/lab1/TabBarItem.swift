import SwiftUI

struct TabBarItem: View {
    let tab: AppTab
    let isSelected: Bool

    var body: some View {
        VStack(spacing: 5) {
            ZStack {
                if tab.isPrimary {
                    primaryIconBackground
                } else {
                    regularIconBackground
                }

                Image(systemName: tab.icon)
                    .font(.system(size: tab.isPrimary ? 25 : 21, weight: .semibold))
                    .foregroundStyle(iconColor)
            }
            .frame(height: 50)

            Text(tab.title)
                .font(.system(size: 11, weight: isSelected ? .semibold : .regular))
                .foregroundStyle(titleColor)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
                .frame(height: 14)
                .opacity(tab.isPrimary ? 0 : 1)
        }
        .frame(maxWidth: .infinity)
        .contentShape(Rectangle())
    }

    private var primaryIconBackground: some View {
        Circle()
            .fill(Color(red: 0.25, green: 0.21, blue: 0.24))
            .frame(width: 48, height: 48)
            .overlay(
                Circle()
                    .stroke(Color.white.opacity(0.55), lineWidth: 2)
                    .padding(5)
            )
    }

    private var regularIconBackground: some View {
        Circle()
            .fill(isSelected ? tab.tint.opacity(0.16) : Color.clear)
            .frame(width: 34, height: 34)
    }

    private var iconColor: Color {
        if tab.isPrimary {
            return Color(red: 0.99, green: 0.73, blue: 0.86)
        }

        return isSelected ? tab.tint : Color(red: 0.68, green: 0.78, blue: 0.86)
    }

    private var titleColor: Color {
        return isSelected ? tab.tint : Color(red: 0.72, green: 0.80, blue: 0.87)
    }
}

#Preview {
    HStack {
        TabBarItem(tab: .bank, isSelected: true)
        TabBarItem(tab: .pet, isSelected: false)
        TabBarItem(tab: .more, isSelected: false)
    }
    .padding()
}
