import SwiftUI

struct ProfileView: View {
    @State private var name = "Имя"

    var body: some View {
        ZStack {
            Color(red: 0.97, green: 0.98, blue: 1.0)
                .ignoresSafeArea()

            VStack(spacing: 22) {
                ProfileHeader()

                AvatarView()

                VStack(spacing: 14) {
                    ProfileCard {
                        EditableNameRow(name: $name)

                        Divider()
                            .overlay(Color(red: 0.93, green: 0.95, blue: 0.98))

                        ProfileRow(
                            icon: "arrow.right.circle.fill",
                            title: "Войти",
                            iconColor: Color(red: 0.10, green: 0.84, blue: 0.30)
                        )
                    }

                    ProfileCard {
                        ProfileRow(
                            icon: "paintpalette.fill",
                            title: "Поменять дизайн",
                            iconColor: Color(red: 0.98, green: 0.19, blue: 0.86)
                        )

                        Divider()
                            .overlay(Color(red: 0.93, green: 0.95, blue: 0.98))

                        ProfileRow(
                            icon: "speaker.wave.2.fill",
                            title: "Звуки и вибрации"
                        )
                    }

                    ProfileCard {
                        ProfileRow(
                            icon: "phone.fill",
                            title: "Позвонить в банк"
                        )

                        Divider()
                            .overlay(Color(red: 0.93, green: 0.95, blue: 0.98))

                        ProfileRow(
                            icon: "questionmark.circle.fill",
                            title: "Ответы на вопросы"
                        )
                    }
                }

                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .padding(.top, 6)
            .padding(.bottom, 30)
        }
        .toolbar(.hidden, for: .navigationBar)
    }
}

#Preview {
    ProfileView()
}
