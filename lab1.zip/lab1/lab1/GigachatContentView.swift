import UIKit

protocol GigachatContentViewDelegate: AnyObject {
    func gigachatContentViewDidTapClose(_ view: GigachatContentView)
    func gigachatContentView(_ view: GigachatContentView, didSend message: String)
}

final class GigachatContentView: UIView {
    weak var delegate: GigachatContentViewDelegate?

    private let closeButton = UIButton(type: .system)
    private let titleLabel = UILabel()
    private let messagesScrollView = UIScrollView()
    private let messagesStack = UIStackView()
    private let bottomStack = UIStackView()
    private let inputContainer = UIView()
    private let inputStack = UIStackView()
    private let plusButton = UIButton(type: .system)
    private let messageTextField = UITextField()
    private let microphoneButton = UIButton(type: .system)
    private let sendButton = UIButton(type: .system)
    private let agreementLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor(red: 0.98, green: 0.98, blue: 1.0, alpha: 1.0)

        setupHeader()
        setupMessagesArea()
        setupInputArea()
        updateSendButtonVisibility()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func addMessage(_ text: String) {
        messagesStack.addArrangedSubview(GigachatMessageBubbleView(text: text))
        layoutIfNeeded()

        let bottomOffset = CGPoint(
            x: 0,
            y: max(0, messagesScrollView.contentSize.height - messagesScrollView.bounds.height + messagesScrollView.adjustedContentInset.bottom)
        )
        messagesScrollView.setContentOffset(bottomOffset, animated: true)
    }

    func clearInput() {
        messageTextField.text = ""
        updateSendButtonVisibility()
    }

    private func setupHeader() {
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = UIColor(red: 0.10, green: 0.11, blue: 0.16, alpha: 1.0)
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.text = "гигачат"
        titleLabel.textAlignment = .center
        titleLabel.textColor = UIColor(red: 0.08, green: 0.08, blue: 0.11, alpha: 1.0)
        titleLabel.font = UIFont.systemFont(ofSize: 22, weight: .black)

        addSubview(closeButton)
        addSubview(titleLabel)

        NSLayoutConstraint.activate([
            closeButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 24),
            closeButton.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor, constant: 20),
            closeButton.widthAnchor.constraint(equalToConstant: 44),
            closeButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerYAnchor.constraint(equalTo: closeButton.centerYAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }

    private func setupMessagesArea() {
        messagesScrollView.translatesAutoresizingMaskIntoConstraints = false
        messagesScrollView.alwaysBounceVertical = true
        messagesScrollView.contentInset = UIEdgeInsets(top: 8, left: 0, bottom: 8, right: 0)
        messagesScrollView.keyboardDismissMode = .interactive
        messagesScrollView.showsVerticalScrollIndicator = false

        messagesStack.translatesAutoresizingMaskIntoConstraints = false
        messagesStack.axis = .vertical
        messagesStack.alignment = .fill
        messagesStack.spacing = 12

        messagesScrollView.addSubview(messagesStack)
        addSubview(messagesScrollView)

        NSLayoutConstraint.activate([
            messagesScrollView.topAnchor.constraint(equalTo: closeButton.bottomAnchor, constant: 28),
            messagesScrollView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            messagesScrollView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),

            messagesStack.topAnchor.constraint(equalTo: messagesScrollView.contentLayoutGuide.topAnchor),
            messagesStack.leadingAnchor.constraint(equalTo: messagesScrollView.contentLayoutGuide.leadingAnchor),
            messagesStack.trailingAnchor.constraint(equalTo: messagesScrollView.contentLayoutGuide.trailingAnchor),
            messagesStack.bottomAnchor.constraint(equalTo: messagesScrollView.contentLayoutGuide.bottomAnchor),
            messagesStack.widthAnchor.constraint(equalTo: messagesScrollView.frameLayoutGuide.widthAnchor)
        ])
    }

    private func setupInputArea() {
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        bottomStack.axis = .vertical
        bottomStack.alignment = .fill
        bottomStack.spacing = 22

        setupInputContainer()
        setupAgreementLabel()

        bottomStack.addArrangedSubview(inputContainer)
        bottomStack.addArrangedSubview(agreementLabel)
        addSubview(bottomStack)

        NSLayoutConstraint.activate([
            inputContainer.heightAnchor.constraint(equalToConstant: 56),

            bottomStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            bottomStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            bottomStack.bottomAnchor.constraint(equalTo: keyboardLayoutGuide.topAnchor, constant: -24),
            messagesScrollView.bottomAnchor.constraint(equalTo: bottomStack.topAnchor, constant: -24)
        ])
    }

    private func setupInputContainer() {
        inputContainer.backgroundColor = UIColor(red: 0.985, green: 0.985, blue: 1.0, alpha: 1.0)
        inputContainer.layer.cornerRadius = 28
        inputContainer.layer.borderWidth = 1
        inputContainer.layer.borderColor = UIColor(red: 0.90, green: 0.90, blue: 0.95, alpha: 1.0).cgColor

        inputStack.translatesAutoresizingMaskIntoConstraints = false
        inputStack.axis = .horizontal
        inputStack.alignment = .center
        inputStack.spacing = 10

        plusButton.setImage(UIImage(systemName: "plus"), for: .normal)
        plusButton.tintColor = UIColor(red: 0.12, green: 0.13, blue: 0.18, alpha: 1.0)

        messageTextField.placeholder = "Спросить или найти"
        messageTextField.borderStyle = .none
        messageTextField.clearButtonMode = .whileEditing
        messageTextField.returnKeyType = .send
        messageTextField.font = UIFont.systemFont(ofSize: 17, weight: .regular)
        messageTextField.textColor = UIColor(red: 0.08, green: 0.09, blue: 0.13, alpha: 1.0)
        messageTextField.delegate = self
        messageTextField.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)

        microphoneButton.setImage(UIImage(systemName: "mic.fill"), for: .normal)
        microphoneButton.tintColor = UIColor(red: 0.12, green: 0.13, blue: 0.18, alpha: 1.0)

        sendButton.setImage(UIImage(systemName: "paperplane.fill"), for: .normal)
        sendButton.tintColor = .white
        sendButton.backgroundColor = UIColor(red: 0.08, green: 0.08, blue: 0.10, alpha: 1.0)
        sendButton.layer.cornerRadius = 17
        sendButton.addTarget(self, action: #selector(sendTapped), for: .touchUpInside)

        [plusButton, microphoneButton, sendButton].forEach { button in
            button.widthAnchor.constraint(equalToConstant: 34).isActive = true
            button.heightAnchor.constraint(equalToConstant: 34).isActive = true
        }

        inputStack.addArrangedSubview(plusButton)
        inputStack.addArrangedSubview(messageTextField)
        inputStack.addArrangedSubview(microphoneButton)
        inputStack.addArrangedSubview(sendButton)
        inputContainer.addSubview(inputStack)

        NSLayoutConstraint.activate([
            inputStack.leadingAnchor.constraint(equalTo: inputContainer.leadingAnchor, constant: 16),
            inputStack.trailingAnchor.constraint(equalTo: inputContainer.trailingAnchor, constant: -14),
            inputStack.topAnchor.constraint(equalTo: inputContainer.topAnchor, constant: 8),
            inputStack.bottomAnchor.constraint(equalTo: inputContainer.bottomAnchor, constant: -8)
        ])
    }

    private func setupAgreementLabel() {
        agreementLabel.numberOfLines = 3
        agreementLabel.textAlignment = .center
        agreementLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        agreementLabel.textColor = UIColor(red: 0.37, green: 0.36, blue: 0.48, alpha: 1.0)

        let text = "Продолжая диалог с ассистентом, вы\nсоглашаетесь с пользовательским\nсоглашением"
        let attributedText = NSMutableAttributedString(string: text)
        if let range = text.range(of: "пользовательским\nсоглашением") {
            attributedText.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: NSRange(range, in: text))
        }
        agreementLabel.attributedText = attributedText
    }

    @objc private func closeTapped() {
        delegate?.gigachatContentViewDidTapClose(self)
    }

    @objc private func textFieldDidChange() {
        updateSendButtonVisibility()
    }

    @objc private func sendTapped() {
        let message = messageTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !message.isEmpty else { return }

        delegate?.gigachatContentView(self, didSend: message)
    }

    private func updateSendButtonVisibility() {
        let hasText = !(messageTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        microphoneButton.isHidden = hasText
        sendButton.isHidden = !hasText
    }
}

extension GigachatContentView: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        sendTapped()
        return true
    }
}
