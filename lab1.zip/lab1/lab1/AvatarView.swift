import SwiftUI

struct AvatarView: View {
    var size: CGFloat = 132

    var body: some View {
        ZStack {
            Circle()
                .fill(Color(red: 0.98, green: 0.92, blue: 0.02))
                .frame(width: size, height: size)

            Image(systemName: "person.fill")
                .font(.system(size: size * 0.52))
                .foregroundStyle(Color(red: 0.07, green: 0.09, blue: 0.13))
        }
    }
}
