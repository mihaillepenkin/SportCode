import UIKit

final class GigachatViewController: UIViewController {
    var onClose: (() -> Void)?

    private let contentView = GigachatContentView()

    init(onClose: (() -> Void)? = nil) {
        self.onClose = onClose
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func loadView() {
        view = contentView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        contentView.delegate = self
    }
}

extension GigachatViewController: GigachatContentViewDelegate {
    func gigachatContentViewDidTapClose(_ view: GigachatContentView) {
        onClose?()
    }

    func gigachatContentView(_ view: GigachatContentView, didSend message: String) {
        print("Гигачат: \(message)")
        view.addMessage(message)
        view.clearInput()
    }
}
