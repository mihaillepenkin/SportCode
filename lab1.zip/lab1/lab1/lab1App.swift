//
//  lab1App.swift
//  lab1
//
//  Created by Максим Вершинин on 14.09.2026.
//

import SwiftUI

@main
struct lab1App: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
