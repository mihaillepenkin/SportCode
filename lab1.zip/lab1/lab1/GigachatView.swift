import SwiftUI

struct GigachatView: UIViewControllerRepresentable {
    let onClose: () -> Void

    func makeUIViewController(context: Context) -> GigachatViewController {
        return GigachatViewController(onClose: onClose)
    }

    func updateUIViewController(_ uiViewController: GigachatViewController, context: Context) {
        uiViewController.onClose = onClose
    }
}
