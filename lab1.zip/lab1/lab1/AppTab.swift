import SwiftUI

enum AppTab: CaseIterable, Identifiable {
    case bank
    case cashback
    case pet
    case tasks
    case more

    var id: AppTab {
        return self
    }

    var title: String {
        switch self {
        case .bank:
            return "Банк"
        case .cashback:
            return "Кэшбэк"
        case .pet:
            return "Питомец"
        case .tasks:
            return "Дела"
        case .more:
            return "Больше"
        }
    }

    var icon: String {
        switch self {
        case .bank:
            return "creditcard.fill"
        case .cashback:
            return "gift.fill"
        case .pet:
            return "pawprint.fill"
        case .tasks:
            return "checkmark.circle.fill"
        case .more:
            return "sparkles"
        }
    }

    var tint: Color {
        switch self {
        case .bank:
            return Color(red: 0.13, green: 0.86, blue: 0.34)
        case .cashback:
            return Color(red: 0.48, green: 0.66, blue: 0.78)
        case .pet:
            return Color(red: 0.99, green: 0.73, blue: 0.86)
        case .tasks:
            return Color(red: 0.54, green: 0.72, blue: 0.84)
        case .more:
            return Color(red: 0.62, green: 0.74, blue: 0.86)
        }
    }

    var isPrimary: Bool {
        return self == .pet
    }
}
