import SwiftUI

struct ProfileRow: View {
    let icon: String
    let title: String
    var iconColor = Color(red: 0.68, green: 0.83, blue: 0.91)

    var body: some View {
        Button {
            // pass
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .foregroundStyle(iconColor)
                    .frame(width: 24)

                Text(title)
                    .foregroundStyle(.primary)
                    .font(.system(size: 15, weight: .semibold))

                Spacer()
            }
            .padding(.horizontal, 16)
            .frame(height: 56)
        }
        .buttonStyle(.plain)
    }
}
